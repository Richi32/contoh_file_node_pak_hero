const notes1=[];

module.exports = notes1 ;